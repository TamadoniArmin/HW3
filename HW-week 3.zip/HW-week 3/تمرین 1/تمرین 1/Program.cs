﻿using System;
Console.Write("Please enter your binary number: ");
string binary = Console.ReadLine();
int number = 0;
for (int i = 0; i < binary.Length; i++)
{
    int temp = int.Parse(binary[i].ToString());
    if (temp == 1)
    {
        number += (int)Math.Pow(2, i);
    }
}
Console.WriteLine($"The number in desimal is: {number}");