﻿using System;
Console.Write("Please enter your number: ");
string number = Console.ReadLine();
string output = "";
for (int i = 0; i < number.Length; i++)
{
    int temp = int.Parse(number[i].ToString());
	if (temp%2==0)
	{
		output += temp.ToString() + '^';
	}
	else
	{
		output += temp.ToString() + '*';
	}
}
string y = deleting(output);
Console.WriteLine($"The new form of your number is: {y}");
string deleting (string x)
{
	string opp = x.Remove(x.Length-1, 1);
	return opp;
}